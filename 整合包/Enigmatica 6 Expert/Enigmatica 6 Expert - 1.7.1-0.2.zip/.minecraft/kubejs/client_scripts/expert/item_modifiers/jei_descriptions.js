onEvent('jei.information', (event) => {
    if (global.isExpertMode == false) {
        return;
    }

    const recipes = [
        {
            items: ['bloodmagic:soulpickaxe'],
            text: ['可开采艾瑟金属矿。']
        },
        {
            items: ['atum:nebu_hammer', 'mythicbotany:alfsteel_pick', 'aiotbotania:alfsteel_aiot'],
            text: ['破坏神铸立方随机掉落阿图姆遗物。']
        },
        {
            items: ['resourcefulbees:t2_apiary', 'resourcefulbees:t3_apiary', 'resourcefulbees:t4_apiary'],
            text: [
                '此步骤将会直接移除蜂巢内的蜜蜂，在执行该步骤之前请确保蜂巢内的蜜蜂被转移出去了！'
            ]
        },
        {
            items: ['industrialforegoing:mob_slaughter_factory'],
            text: [
                // This works but doesn't provide color in JEI text.
                // I just made it like this to be easily copied from tooltips script
                Text.of('在专家模式下被禁用。').red(),
                Text.of('肉汤可以通过“处理”牛来获得。').color('#6e2a2a'),
                Text.of('粉红黏液可以用流体镭射钻从粉色凋灵处收获。').color('#da07e6')
            ]
        },
        {
            items: ['refinedstorage:4k_storage_part', 'refinedstorage:1k_storage_part'],
            text: ['该配方在专家模式被禁用，请从16K存储元件开始合成。']
        },
        {
            items: ['refinedstorage:256k_fluid_storage_part', 'refinedstorage:64k_fluid_storage_part'],
            text: ['该配方在专家模式被禁用，请从1024k流体存储元件开始合成。']
        },
        {
            items: [
                'kubejs:medium_machinery_schematics',
                'kubejs:heavy_machinery_schematics',
                'occultism:chalk_red',
                'bloodmagic:masterbloodorb',
                'bloodmagic:soulgemlesser'
            ],
            text: [
                '首次获得该物品时自动解锁一个新的阶段。',
                '如果未成功解锁阶段请手持该物品在空中右键。'
            ]
        }
    ];

    recipes.forEach((recipe) => {
        recipe.items.forEach((item) => {
            event.add(item, recipe.text);
        });
    });

    const disabledItems = [
        'pneumaticcraft:air_compressor',
        'pneumaticcraft:advanced_air_compressor',
        'integrateddynamics:energy_battery',
        'integrateddynamics:mechanical_squeezer',
        'integrateddynamics:mechanical_drying_basin',
        'integrateddynamics:squeezer',
        'integrateddynamics:drying_basin',
        'integrateddynamics:coal_generator',
        'mekanism:upgrade_filter',
        'darkutils:rune_damage_player',
        'integrateddynamics:coal_generator',
        /darkutils:export_plate/,
        /integrateddynamics:energy_battery/,
        /powah:energy_cable_/,
        'eidolon:crucible',
        'eidolon:wooden_brewing_stand',
        'engineersdecor:factory_placer',
        'pedestals:coin/rfexpgen',
        'pedestals:coin/rffuelgen'
    ];
    disabledItems.forEach((item) => {
        event.add(
            item,
            "该物品在专家模式下被禁用，如果你通过非作弊的手段获得了它，请在本整合包的Github上向作者反馈该问题，链接：https://github.com/NillerMedDild/Enigmatica6/issues"
        );
    });
});
