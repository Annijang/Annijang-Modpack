onEvent('recipes', (event) => {
    /* Usage Documentation: https://github.com/TeamPneumatic/pnc-repressurized/wiki/Amadron-and-Datapacks#1152 */
    const id_prefix = 'enigmatica:base/pneumaticcraft/amadron/';

    const recipes = [
        {
            static: true,
            input: { type: 'ITEM', id: 'kubejs:amadron_survey_tools', amount: 1 },
            output: {
                type: 'ITEM',
                id: 'pneumaticcraft:reinforced_chest',
                amount: 1,
                nbt: `{display:{Name:'[{"text":"矿物探测器 - 阿图姆"}]',Lore:['[{"text":"放置后可随机获得来自阿图姆维度的矿物宝藏。","color":"gold"}]']},BlockEntityTag:{LootTable:"enigmatica:chests/amadron_mineral_survey_atum_combo"}}`
            },
            level: 0,
            maxStock: 5,
            whitelist: { and: { dimensions: ['atum:atum'] } },
            id: `${id_prefix}mineral_survey_atum`
        },
        {
            static: true,
            input: { type: 'ITEM', id: 'kubejs:amadron_survey_tools', amount: 1 },
            output: {
                type: 'ITEM',
                id: 'pneumaticcraft:reinforced_chest',
                amount: 1,
                nbt: `{display:{Name:'[{"text":"矿物探测器 - 深暗之园"}]',Lore:['[{"text":"放置后可随机获得来自深暗之园维度的矿物宝藏。","color":"gold"}]']},BlockEntityTag:{LootTable:"enigmatica:chests/amadron_mineral_survey_undergarden_combo"}}`
            },
            level: 0,
            maxStock: 5,
            whitelist: { and: { dimensions: ['undergarden:undergarden'] } },
            id: `${id_prefix}mineral_survey_undergarden`
        },
        {
            static: true,
            input: { type: 'ITEM', id: 'kubejs:amadron_survey_tools', amount: 1 },
            output: {
                type: 'ITEM',
                id: 'pneumaticcraft:reinforced_chest',
                amount: 1,
                nbt: `{display:{Name:'[{"text":"植物探测器 - 下界"}]',Lore:['[{"text":"放置后可随机获得来自下界维度的植物宝藏。","color":"gold"}]']},BlockEntityTag:{LootTable:"enigmatica:chests/amadron_botanical_survey_nether_combo"}}`
            },
            level: 0,
            maxStock: 5,
            whitelist: { and: { dimensions: ['minecraft:the_nether'] } },
            id: `${id_prefix}botanical_survey_nether`
        },
        {
            static: true,
            input: { type: 'ITEM', id: 'kubejs:amadron_survey_tools', amount: 1 },
            output: {
                type: 'ITEM',
                id: 'pneumaticcraft:reinforced_chest',
                amount: 1,
                nbt: `{display:{Name:'[{"text":"植物探测器 - 末地"}]',Lore:['[{"text":"放置后可随机获得来自末地维度的植物宝藏。","color":"gold"}]']},BlockEntityTag:{LootTable:"enigmatica:chests/amadron_botanical_survey_end_combo"}}`
            },
            level: 0,
            maxStock: 5,
            whitelist: { and: { dimensions: ['minecraft:the_end'] } },
            id: `${id_prefix}botanical_survey_end`
        },
        {
            static: true,
            input: { type: 'ITEM', id: 'kubejs:amadron_survey_tools', amount: 1 },
            output: {
                type: 'ITEM',
                id: 'pneumaticcraft:reinforced_chest',
                amount: 1,
                nbt: `{display:{Name:'[{"text":"矿物探测器 - 末地"}]',Lore:['[{"text":"放置后可随机获得来自末地维度的矿物宝藏。","color":"gold"}]']},BlockEntityTag:{LootTable:"enigmatica:chests/amadron_mineral_survey_the_end_combo"}}`
            },
            level: 0,
            maxStock: 5,
            whitelist: { and: { dimensions: ['minecraft:the_end'] } },
            id: `${id_prefix}mineral_survey_the_end`
        }
    ];

    recipes.forEach((recipe) => {
        recipe.type = 'pneumaticcraft:amadron';
        event.custom(recipe).id(recipe.id);
    });
});

/**/
