onEvent('jei.information', (event) => {
    if (global.isNormalMode == false) {
        return;
    }
    const recipes = [
        {
            items: ['resourcefulbees:t2_apiary', 'resourcefulbees:t3_apiary', 'resourcefulbees:t4_apiary'],
            description: [
                '只有当所有的蜂巢/蜂箱被放置在世界上并获得NBT标签时，制作等级蜂巢才会将已存在的蜜蜂返回到合成后的蜂巢/蜂箱中。'
            ]
        },
        {
            items: ['atum:nebu_hammer'],
            description: ['破坏神铸立方时会随机掉落阿图姆遗物。']
        }
    ];

    recipes.forEach((recipe) => {
        recipe.items.forEach((item) => {
            event.add(item, recipe.description);
        });
    });
});
