onEvent('jei.information', (event) => {
    const recipes = [
        {
            items: ['simplefarming:cheese_slice'],
            text: ['右击奶酪圈获得。']
        },
        {
            items: ['farmersdelight:ham'],
            text: ['用小刀击杀猪或疣猪兽获得。']
        },
        {
            items: ['astralsorcery:stardust'],
            text: [
                '用星辉锭切割工具左击星辉锭获得，更多内容请在《星芒宝典》中查看。'
            ]
        },
        {
            items: ['buildinggadgets:construction_paste'],
            text: ['使用镐子破坏致密构建方块获得。']
        },
        {
            items: ['powah:uraninite', 'powah:uraninite_block'],
            text: [
                '铀矿被移除了且不会自然生成，使用Powah的充能台配方来获得晶质铀。'
            ]
        },
        {
            items: ['thermal:blizz_rod', 'thermal:blizz_spawn_egg'],
            text: [
                '暴雪人生成于寒冷的生物群系中，使用机械诅咒之土或暗夜粉生成它们会更简单。'
            ]
        },
        {
            items: ['thermal:blitz_rod', 'thermal:blitz_spawn_egg'],
            text: [
                '狂风人生成于温暖干燥的生物群系中，使用机械诅咒之土或暗夜粉生成它们会更简单。'
            ]
        },
        {
            items: ['thermal:basalz_rod', 'thermal:basalz_spawn_egg'],
            text: [
                '岩石人通常出没于贫瘠或多山的生物群系或下界的玄武岩三角洲中，使用机械诅咒之土或暗夜粉生成它们会更简单。'
            ]
        },
        {
            items: ['betterendforge:emerald_ice'],
            text: [
                '可以在末地中的冰晶之星中找到，也可以通过在古翡翠冰旁边放水获得。'
            ]
        },
        {
            items: ['betterendforge:dense_emerald_ice'],
            text: [
                '可以在末地中的冰晶之星中找到，也可以通过在古翡翠冰旁边放水获得。'
            ]
        },
        {
            items: ['betterendforge:ancient_emerald_ice'],
            text: [
                '可以在末地中的冰晶之星中找到，也可以通过在古翡翠冰旁边放水获得，也可以通过手动合成致密翡翠冰获得。'
            ]
        },
        {
            items: ['simplefarming:habanero'],
            text: ['收获辣椒时的稀有掉落物。']
        },
        {
            items: ['mekanismgenerators:fusion_reactor_controller'],
            text: [
                '聚变反应堆被大幅削弱。',
                '被动产生6万-25万rf/t的电量，但如果与一个甚至多个蒸汽涡轮搭配，那么聚变反应堆可以产出更多的电量。'
            ]
        },
        {
            items: [
                'industrialforegoing:infinity_backpack',
                'industrialforegoing:infinity_saw',
                'industrialforegoing:infinity_drill',
                'industrialforegoing:infinity_hammer',
                'industrialforegoing:infinity_trident',
                'industrialforegoing:infinity_nuke',
                'industrialforegoing:infinity_launcher'
            ],
            text: [
                "九万亿是个非常庞大的数字，大到让人难以想象。"
            ]
        },
        {
            items: [
                'industrialforegoing:infinity_backpack',
                'industrialforegoing:infinity_saw',
                'industrialforegoing:infinity_drill',
                'industrialforegoing:infinity_hammer',
                'industrialforegoing:infinity_trident',
                'industrialforegoing:infinity_nuke',
                'industrialforegoing:infinity_launcher'
            ],
            text: [
                "除非你打算给它充一辈子的电，否则通过正常方法是无法充满的，但有人说获取答案就藏在核合成室里。"
            ]
        },
        {
            items: ['farmersdelight:brown_mushroom_colony', 'minecraft:brown_mushroom'],
            text: [
                '将棕色蘑菇种在黑暗环境下的沃土上来长成蘑菇菌丛，破坏后可以获得较为不错的收益。'
            ]
        },
        {
            items: ['farmersdelight:red_mushroom_colony', 'minecraft:red_mushroom'],
            text: [
                '将红色蘑菇种在黑暗环境下的沃土上来长成蘑菇菌丛，破坏后可以获得较为不错的收益。'
            ]
        },
        {
            items: [
                'integratedtunnels:part_interface_energy',
                'integratedtunnels:part_importer_energy',
                'integratedtunnels:part_exporter_energy'
            ],
            text: ['传输速度：65536 rf/t']
        },
        {
            items: [
                'integratedtunnels:part_interface_fluid',
                'integratedtunnels:part_importer_fluid',
                'integratedtunnels:part_exporter_fluid'
            ],
            text: ['传输速度：65536 mb/t']
        },
        {
            items: ['minecraft:nautilus_shell'],
            text: [
                '击杀位于暖水海洋的鹦鹉螺获得。',
                ' ',
                '你也可以通过在海洋或者沙滩的地下找“包埋鹦鹉螺的石头”并将其烧制获得。'
            ]
        },
        {
            items: ['architects_palette:twisted_sapling'],
            text: ['在主世界向下界传送门投掷树苗获得。']
        },
        {
            items: ['architects_palette:warpstone'],
            text: ['在主世界向下界传送门投掷粘土块获得。']
        },
        {
            items: ['byg:warped_cactus'],
            text: ['在主世界向下界传送门投掷仙人掌获得。']
        },
        {
            items: ['byg:warped_coral', 'byg:warped_coral_fan', 'byg:warped_coral'],
            text: ['在主世界向下界传送门投掷任意珊瑚获得。']
        },
        {
            items: ['architects_palette:chiseled_abyssaline_bricks'],
            text: ['可以用海洋之心右击充能，用于给渊晶石方块供能。']
        },
        {
            items: [
                'architects_palette:abyssaline_lamp',
                'architects_palette:abyssaline_tile_slab',
                'architects_palette:abyssaline_tiles',
                'architects_palette:abyssaline_brick_slab',
                'architects_palette:abyssaline_pillar',
                'architects_palette:abyssaline_bricks',
                'architects_palette:abyssaline'
            ],
            text: [
                '旁边放置充能錾制渊晶石砖时会被供能，能量可以通过其他渊晶石方块传递。'
            ]
        },
        {
            items: [
                'architects_palette:blank_acacia_totem',
                'architects_palette:shocked_acacia_totem',
                'architects_palette:placid_acacia_totem',
                'architects_palette:grinning_acacia_totem'
            ],
            text: ['手持任意斧头右键图腾可改变图腾图案。']
        },
        {
            items: ['betterendforge:silk_fiber'],
            text: ['击杀生成在蚕蛾巢穴的蚕蛾获得。']
        },
        {
            items: [/upgrade_aquatic:(?!.*dead_coralstone|chiseled)(?=.*_coralstone$)/],
            text: ['将珊瑚石放到活珊瑚旁边等待成熟然后使用带有精准采集附魔的工具采集获得。']
        },
        {
            items: ['upgrade_aquatic:coralstone'],
            text: ['放置在活珊瑚旁等待灌注。']
        },
        {
            items: ['upgrade_aquatic:dead_coralstone'],
            text: ['使用不带精准采集附魔的工具采集获得。']
        },
        {
            items: [
                'quark:red_crystal',
                'quark:orange_crystal',
                'quark:yellow_crystal',
                'quark:green_crystal',
                'quark:blue_crystal',
                'quark:indigo_crystal',
                'quark:violet_crystal',
                'quark:white_crystal',
                'quark:black_crystal'
            ],
            text: [
                '如果放置在地底深处，就会长四格高，在生长过程时会有粒子效果。.',
                ' ',
                '也许还有可能会长出刚玉簇。'
            ]
        },
        {
            items: [/quark:\w+_crystal_cluster/],
            text: ['在地底深处的刚玉方块在生长时随机出现。']
        },
        {
            items: ['quark:bottled_cloud'],
            text: ['在高度为126到132之间手持空玻璃瓶右键空气获得。']
        },
        {
            items: [Item.of('naturesaura:aura_bottle', { stored_type: 'naturesaura:overworld' })],
            text: [
                '在主世界或阿图姆世界使用用瓶与塞右击空气获得，此步骤会将该地区的灵气清除。',
                ' ',
                `可通过发射器自动化。`
            ]
        },
        {
            items: [Item.of('naturesaura:aura_bottle', { stored_type: 'naturesaura:end' })],
            text: [
                '在末地或深暗之园使用瓶与塞右击空气获得，此步骤会将该地区的灵气清除。',
                ' ',
                `可通过发射器自动化。`
            ]
        },
        {
            items: [Item.of('naturesaura:aura_bottle', { stored_type: 'naturesaura:nether' })],
            text: [
                '在下界使用瓶与塞右击空气获得，此步骤会将该地区的灵气清除。',
                ' ',
                `可通过发射器自动化。`
            ]
        },
        {
            items: ['quark:root_item'],
            text: [
                '破坏洞穴根茎时随机掉落。',
                ' ',
                '洞穴根茎可以像藤蔓一样合成和生长，只不过它们需要在低亮度的地方才会生长。'
            ]
        },
        {
            items: ['quark:root'],
            text: ['可以像藤蔓一样合成和生长，只不过它们需要在低亮度的地方才会生长。']
        },
        {
            items: ['meetyourfight:phantoplasm'],
            text: ['由敲钟人掉落，用缠魂铃铛召唤。']
        },
        {
            items: ['meetyourfight:mossy_tooth'],
            text: ['由沼泽巨颌怪掉落，用化石之饵召唤。']
        },
        {
            items: ['meetyourfight:fortunes_favor'],
            text: [`由福尔图娜女爵掉落，用恶魔赌注召唤。`]
        },
        {
            items: ['atum:ectoplasm'],
            text: [`由阿图姆的沙漠废墟中的怨灵掉落。`]
        },
        {
            items: ['minecraft:firework_rocket'],
            text: [`无序合成，需要一张纸和一个火药。`]
        },
        {
            items: ['minecraft:firework_rocket'],
            text: [
                `可以通过添加更多的火药来延长烟花火箭的飞行时间。`,
                `最多只能添加三个火药或者七个烟火之星。`
            ]
        },
        {
            items: ['minecraft:firework_star'],
            text: [`无序和成，需要一个火药和一种染料。`]
        },
        {
            items: ['minecraft:firework_star'],
            text: [
                `最多只能添加八种染料。`,
                `可以添加头颅、金粒、羽毛或者火焰弹来改变形状。`,
                `钻石和萤石粉也能被一起添加进烟花火箭中。`
            ]
        },
        {
            items: ['minecraft:dragon_egg'],
            text: [
                `反复召唤末影龙可以获得更多的龙蛋。`,
                ` `,
                `在末地传送门四周的中心位置（东南西北）分别放上一个末影水晶来召唤末影龙。`
            ]
        },
        {
            items: ['byg:leaf_pile'],
            text: [`可使用剪刀采集。`]
        },
        {
            items: ['eidolon:soul_shard'],
            text: [
                `通过在亡灵生物周围举行结晶仪式获得，结晶仪式可在《秘仪教典》中找到。`,
                ` `,
                `也可以通过使用死神镰刀击杀亡灵生物获得。`
            ]
        },
        {
            items: ['atum:anputs_fingers_spores'],
            text: [`可在死树木下发现，需要黑暗环境才能生长。`]
        },
        {
            items: ['immersiveengineering:furnace_heater', 'mekanism:fuelwood_heater', 'mekanism:resistive_heater'],
            text: [`可为气动工艺的机器提供热量。`]
        },
        {
            items: ['immersiveengineering:logic_circuit'],
            text: [
                `在逻辑单元中用于制作更高级的红石逻辑。`,
                ` `,
                `在工程师电路台中合成，背板（电路板）、逻辑组件（真空管）、焊料（铜线或者铅线）三种原料，除了最基础的SET模式之外所有的运算模式都需要逻辑组件（真空管）。`
            ]
        },
        {
            items: ['alexsmobs:hemolymph_sac', 'alexsmobs:warped_muscle'],
            text: [
                `击败诡异蚊鬼后获得。`,
                ` `,
                `诡异蚊鬼是一种由绯红蚊子突变形成的怪物，玩家需要前往蘑菇岛找到一个没有蘑菇的哞菇，然后用诡异菌插满它的身体（5个即可），让绯红蚊子吸它的血，然后绯红蚊子会变成蓝色并慢慢变大，最后突变成诡异蚊鬼。`
            ]
        },
        {
            items: ['alexsmobs:hemolymph_sac', 'alexsmobs:warped_muscle'],
            text: [
                `哞菇可在降生祭坛中召唤，而绯红蚊子可以由苍蝇在下界转变而来。`
            ]
        },
        {
            items: ['astralsorcery:gem_crystal_cluster'],
            text: [
                `将水晶石或天体水晶石和辉光粉一起丢进星能液形成。`,
                ` `,
                `不同的水晶石在不同的时间内能产生的宝石种类也会不同。`
            ]
        },
        {
            items: ['astralsorcery:celestial_crystal_cluster'],
            text: [`将水晶石或天体水晶石和星尘一起丢进星能液形成。`]
        },
        {
            items: ['astralsorcery:celestial_crystal_cluster'],
            text: [
                `在星辉矿上生长时速度更快，天体水晶簇在首次成长时会将下方的星辉矿退化成铁矿，所以需要用聚能水晶链接将其转换回来。`
            ]
        },
        {
            items: ['bloodmagic:weak_tau'],
            text: [`可在恶魔领域的箱子中找到。`]
        },
        {
            items: ['bloodmagic:strong_tau'],
            text: [`如果在血命果生长之时上方有牛，羊等友善动物，血命果会对其造成伤害，最终成长为饱满血命果`]
        },
        {
            items: ['eidolon:unholy_symbol'],
            text: [`通过对掉落在地上的锡镴嵌材咏唱“黑暗的触摸”仪式获得。`]
        },
        {
            items: [
                'resourcefulbees:t1_beehive',
                'resourcefulbees:t2_beehive',
                'resourcefulbees:t3_beehive',
                'resourcefulbees:t4_beehive'
            ],
            text: [
                `等级蜂巢被禁用了，请使用在世界中自然生成的蜂巢，并对蜂巢使用蜂巢升级，等级蜂巢可在工作台中合成为对应的蜂巢升级。`
            ]
        },
        {
            items: ['upgrade_aquatic:flare_spawn_egg'],
            text: [`对幻翼喷溅失眠药水将其转变成耀翼。`]
        },
        {
            items: ['immersiveengineering:cloche'],
            text: [
                `可用肥料列表：`,
                ` `,
                `骨粉：1.25x`,
                `花肥：1.5x`,
                `绿色堆肥：1.5x`,
                `肥料：1.7x`,
                `红色堆肥：2.0x`,
                `植育一号：3.0x`
            ]
        },
        {
            items: ['quark:dragon_scale'],
            text: [`首次击杀末影龙时，龙鳞就会从末影龙身上掉落。`]
        },
        {
            items: [
                'dankstorage:1_to_2',
                'dankstorage:2_to_3',
                'dankstorage:3_to_4',
                'dankstorage:4_to_5',
                'dankstorage:5_to_6',
                'dankstorage:6_to_7'
            ],
            text: [`潜行右键升级坞里的黑盒。`]
        },
        {
            items: [Item.of('resourcefulbees:bee_jar', { Entity: 'resourcefulbees:dusty_mummbee_bee' })],
            text: [`异沙蜜蜂可以在法老的石棺中找到。`]
        },
        {
            items: ['quark:slime_in_a_bucket'],
            text: [`用空桶把小史莱姆装起来。`]
        },
        {
            items: ['alexsmobs:mysterious_worm'],
            text: [
                `将神秘蠕虫丢入末地的虚空中，即可召唤虚空蠕虫。`,
                ` `,
                `将绯红蚊子幼虫放入衣壳中，等待片刻后，将会掉落神秘蠕虫。`
            ]
        },
        {
            items: ['alexsmobs:capsid'],
            text: [
                `由末影噬菌体掉落。`,
                ` `,
                `影噬菌体罕见地生成在末地中型岛屿上，服用异界蜂蜜瓶也可强行召唤它们。`
            ]
        },
        {
            items: ['eidolon:sanguine_amulet', 'eidolon:sapping_sword'],
            text: [`有关制作步骤，请参考《秘仪教典》中的深红之物章节。`]
        },
        {
            items: ['atum:papyrus_plant'],
            text: [
                `通常在阿图姆的绿洲中找到，像甘蔗一样，只不过生长在怪沙或肥沃土壤上。`
            ]
        },
        {
            items: ['astralsorcery:infused_wood'],
            text: [`将任意种类木头丢进星能液中获得。`]
        },
        {
            items: ['environmental:thief_hood'],
            text: [`可使用兔子皮进行修复。`]
        },
        {
            items: ['naturesaura:gold_leaf'],
            text: [`破坏黄金叶时获得。`]
        },
        {
            items: ['naturesaura:golden_leaves'],
            text: [`通过使用闪耀纤维右键树叶获得，等待一段时间被感染过的树叶会慢慢扩散感染其它相邻的树叶。`]
        },
        {
            items: [/masterfulmachinery:\w+_controller/],
            text: [`人工搭建该结构难度很大。`]
        },
        {
            items: [/masterfulmachinery:\w+_controller/],
            text: [
                `你可以在"building_gadgets_patterns"文件夹中找到有关复制粘贴小帮手的对应模板。`,
                ` `,
                '可以旋转，但是无法镜像。'
            ]
        },

        {
            items: [/masterfulmachinery:\w+_controller/],
            text: [
                '关于这些机器信息的相关说明：',
                `●FE在每个游戏刻都会被消耗`,
                `●气动相关的压缩空气在每个游戏刻都会被消耗，但压力必须大于10Bar`,
                `●星辉相关的星能液在每个游戏刻都会被消耗`,
                `●每个游戏刻都会消耗液体或者生成液体`,
                `●每个物品都会在合成结束后被消耗或者生成`,
                `●魔力在合成开始或者结束后消耗或者生成`
            ]
        },
        {
            items: ['naturesaura:break_prevention'],
            text: [
                `在铁砧里给工具使用该物品之后，工具在耐久即将耗尽后会停止工作，而不是直接损坏消失。`
            ]
        },
        {
            items: ['ars_nouveau:belt_of_levitation'],
            text: [`装备在腰带槽后，在空中按下潜行键悬浮。`]
        },
        {
            items: ['create:chromatic_compound', 'create:refined_radiance'],
            text: [
                `异彩化合物被丢弃后，如果吸收光亮，逐渐转变成光辉石，在自然环境光下的转换非常缓慢，周围有光源方块会更快，在激活的信标上会瞬间转化。`
            ]
        },
        {
            items: ['create:chromatic_compound', 'create:shadow_steel'],
            text: [
                `异彩化合物被丢弃后，如果坠入虚空，吸收黑暗，则会转变成暗影钢，在完成转化后会浮上来。`
            ]
        },
        {
            items: ['naturesaura:projectile_generator'],
            text: [`有效的弹射物：`, ``, `● 雪球`, `● 鸡蛋`, `● 箭矢`, `● 火焰弹`, `● 光灵箭`]
        },
        {
            items: ['naturesaura:projectile_generator'],
            text: [`● 末影珍珠`, `● 羊驼的口水`, `● 附魔之瓶`, `● 潜影贝的导弹`, `● 三叉戟`]
        },
        {
            items: ['naturesaura:birth_spirit'],
            text: [`在灵气过量的区块内繁殖动物获得。`]
        },
        {
            items: ['create:hose_pulley'],
            text: [
                `软管滑轮可无限的抽取以下液体：`,
                ` `,
                `● 熔岩`,
                `● 水`,
                `● 牛奶`,
                `● 胶乳`,
                `● 污水`,
                `● 污泥`,
                `● 石油`,
                `● 树脂`,
                `● 树汁`,
                `● 致毒混合物`,
                `● 建筑工茶饮`,
                `● 巧克力`,
                `● 紫颂果浆`,
                `● 门瑞欧树脂`,
                `● 血`,
                `● 黏液`,
                `● 末影黏液`,
                `● 碧空黏液`
            ]
        },
        {
            items: ['farmersdelight:honey_glazed_ham'],
            text: [`用碗右键放置的蜜汁火腿获得。`]
        },
        {
            items: ['farmersdelight:stuffed_pumpkin'],
            text: [`用碗右键放置的填馅南瓜获得。`]
        },
        {
            items: ['farmersdelight:roast_chicken'],
            text: [`用碗右键放置的烤鸡获得。`]
        },
        {
            items: ['simplefarming:brewing_barrel'],
            text: [`用于酿造各种酒精饮料。`, ` `, `●啤酒`, `●巴西啤酒`, `●苹果酒`, `●蜂蜜酒`]
        },
        {
            items: ['simplefarming:brewing_barrel'],
            text: [`●日式清酒`, `●美式格瓦斯`, `●伏特加`, `●威士忌`, `●红酒`]
        }
    ];

    const simplefarming_beverages = [
        { type: 'beer', ingredient: '大麦', effect: '力量' },
        { type: 'cauim', ingredient: '木薯', effect: '跳跃提升' },
        { type: 'cider', ingredient: '苹果', effect: '幸运' },
        { type: 'mead', ingredient: '蜜脾', effect: '急迫' },
        { type: 'sake', ingredient: '水稻', effect: '速度' },
        { type: 'tiswin', ingredient: '仙人掌果', effect: '生命提升' },
        { type: 'vodka', ingredient: '马铃薯', effect: '抗性提升' },
        { type: 'whiskey', ingredient: '小麦', effect: '伤害吸收' },
        { type: 'wine', ingredient: '葡萄', effect: '生命恢复' }
    ];

    simplefarming_beverages.forEach((beverage) => {
        recipes.push({
            items: [`simplefarming:${beverage.type}`],
            text: [
                `将${beverage.ingredient}右键放进酿造桶酿造而成。`,
                `饮用后获得${beverage.effect}。`
            ]
        });
    });

    recipes.forEach((recipe) => {
        recipe.items.forEach((item) => {
            event.add(item, recipe.text);
        });
    });

    disabledItems.forEach((item) => {
        event.add(
            item,
            "该物品在本整合包中被禁用，如果你通过非作弊的手段获得了它，请在本整合包的Github上向作者该问题，链接是：https://github.com/EnigmaticaModpacks/Enigmatica6/issues"
        );
    });

    refinedStorageItems.forEach((item) => {
        event.add(`refinedstorage:${item}`, '可通过合成或在世界中右键来染色。');
    });

    generatableCobblestone.forEach((cobblestone) => {
        event.add(
            cobblestone,
            '可通过原版的刷石机生成，只不过在生成圆石的下方需要放置一个铁块。'
        );
    });

    generatableStone.forEach((stone) => {
        event.add(
            stone,
            '可通过原版的刷石机生成，只不过在生成圆石的下方需要放置一个钻石块。'
        );
    });

    var framedDrawers = [
        'compact_drawer',
        'drawer_controller',
        'slave',
        'trim',
        'full_one',
        'full_two',
        'full_four',
        'half_one',
        'half_two',
        'half_four'
    ];

    framedDrawers.forEach((drawer) => {
        event.add('framedcompactdrawers:framed_' + drawer, [
            '镶框抽屉无法立即使用，需要先将方块镶嵌到抽屉里才能使用，打开物品栏，将镶框抽屉放到物品栏自带的2x2合成栏的右下角上，然后在左侧、左上角、上面三选一然后放置一个方块来将方块镶嵌到抽屉里。',
            '你可以使用不同的方块来为你的镶框抽屉进一步地自定义外观！'
        ]);
    });
});
