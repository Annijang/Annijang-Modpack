onEvent('item.tooltip', (event) => {
    /*
    Valid Color Codes:
    
    .black()
    .darkBlue()
    .darkGreen()
    .darkAqua()
    .darkRed()
    .darkPurple()
    .gold()
    .gray()
    .darkGray()
    .blue()
    .green()
    .aqua()
    .red()
    .lightPurple()
    .yellow()
    .white()
    .color('#808080') //any hex color
    */
    const recipes = [
        {
            items: [
                'integratedtunnels:part_interface_fluid',
                'integratedtunnels:part_importer_fluid',
                'integratedtunnels:part_exporter_fluid'
            ],
            text: [Text.of('传输速度：65536 mb/t').red()]
        },
        {
            items: [
                'integratedtunnels:part_interface_energy',
                'integratedtunnels:part_importer_energy',
                'integratedtunnels:part_exporter_energy'
            ],
            text: [Text.of('传输速度：65536 rf/t').red()]
        },
        {
            items: ['powah:charged_snowball', 'thermal:lightning_charge'],
            text: [Text.of('在撞击点召唤一道闪电').gold()]
        },
        {
            items: ['kubejs:altered_recipe_indicator'],
            text: [Text.of('在专家模式中该配方已被更改，请在JEI中查看').gold()]
        },
        {
            items: ['kubejs:disabled_recipe_indicator'],
            text: [Text.of('该配方在本整合包中已被禁用').gold()]
        },
        {
            items: ['tconstruct:crafting_station', 'tconstruct:part_builder', 'tconstruct:tinker_station'],
            text: [Text.of('任意木头可参与合成').gold()]
        },
        {
            items: ['tconstruct:scorched_anvil', 'tconstruct:tinkers_anvil'],
            text: [Text.of('任意合金块可参与合成').gold()]
        },
        {
            items: [
                'engineersdecor:rebar_concrete_tile_stairs',
                'engineersdecor:rebar_concrete_tile_slab',
                'engineersdecor:rebar_concrete_tile',
                'engineersdecor:rebar_concrete_wall',
                'engineersdecor:rebar_concrete_stairs',
                'engineersdecor:rebar_concrete_slab',
                'engineersdecor:rebar_concrete',
                'thermal:enderium_glass',
                'thermal:lumium_glass',
                'thermal:signalum_glass',
                'thermal:obsidian_glass',
                'engineersdecor:panzerglass_block'
            ],
            text: [Text.of('可用于抵御凋灵').color('#4F0D75')]
        },
        {
            items: ['modularrouters:blast_upgrade'],
            text: [Text.of('使路由器可抵御凋灵').color('#4F0D75')]
        },
        {
            items: ['astralsorcery:illumination_wand'],
            text: [Text.of('使方块能抵御凋灵').color('#4F0D75')]
        },
        {
            items: [
                'rftoolsbuilder:shield_block4',
                'rftoolsbuilder:shield_block3',
                'rftoolsbuilder:shield_block2',
                'rftoolsbuilder:shield_block1'
            ],
            text: [Text.of('护盾投射仪可抵御凋灵').color('#4F0D75')]
        },
        {
            items: [/bloodmagic:quick_draw_anointment/],
            text: [Text.of('使弓和弩获得快速拉弓的效果').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:fortune_anointment/],
            text: [Text.of('使工具获得额外的时运效果').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:holy_water_anointment/],
            text: [Text.of('增加对亡灵的近战伤害').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:melee_anointment/],
            text: [Text.of('增加近战伤害').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:bow_power_anointment/],
            text: [Text.of('增加弓和弩的箭矢伤害').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:silk_touch_anointment/],
            text: [Text.of('获得精准采集效果').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:hidden_knowledge_anointment/],
            text: [Text.of('破坏方块获得额外经验').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:smelting_anointment/],
            text: [Text.of('获得自动冶炼效果').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:looting_anointment/],
            text: [Text.of('使武器获得额外的掠夺效果').color('#7e24b3')]
        },
        {
            items: [/bloodmagic:bow_velocity_anointment/],
            text: [Text.of('增加弓和弩的箭矢飞行速度').color('#7e24b3')]
        },
        {
            items: ['#enigmatica:burning_hot'],
            text: [Text.of('超烫！').darkRed()]
        },
        {
            items: [
                'resourcefulbees:t1_beehive',
                'resourcefulbees:t2_beehive',
                'resourcefulbees:t3_beehive',
                'resourcefulbees:t4_beehive'
            ],
            text: [
                Text.of(`等级蜂箱已被禁用。`).red(),
                Text.of(`请使用在世界中自然生成的蜂巢，并对蜂巢使用蜂巢升级。`).red(),
                Text.of(`等级蜂巢可在工作台内转换成对应的蜂巢升级。`).red()
            ]
        },
        {
            items: [/natures\w+:\w+_generator/],
            text: [Text.of(`灵气生成器`).green()]
        },
        {
            items: ['clockout:clockout_block'],
            text: [Text.of(`玩家在线时发出红石信号`).aqua()]
        },
        {
            items: ['kubejs:soggy_treasure_box'],
            text: [Text.of(`这个容器的锁似乎坏了...里面会有什么？`).darkAqua()]
        },
        {
            items: [/masterfulmachinery:\w+_mana_port/],
            text: [Text.of(`与魔力发射器和火花兼容`).green()]
        },
        {
            items: ['kubejs:amadron_survey_tools'],
            text: [Text.of(`亚马龙无人机使用的工具，用于交换稀有资源`).aqua()]
        },
        {
            items: ['kubejs:monster_mash'],
            text: [Text.of(`...它在一瞬间就被抓住了...`).red()]
        },
        {
            items: ['refinedstorage:silk_touch_upgrade'],
            text: [Text.of('对刷怪笼无效。').red()]
        },
        {
            items: [
                'kubejs:crystalline_flowering_palo_verde_leaves',
                'kubejs:crystalline_oak_leaves',
                'kubejs:crystalline_dark_oak_wood'
            ],
            text: [Text.of('防火').gold()]
        }
    ];

    refinedStorageItems.forEach((item) => {
        recipes.push({
            items: [`refinedstorage:${item}`],
            text: ['可以通过合成染色或在世界中右键染色']
        });
    });

    recipes.forEach((recipe) => {
        event.add(recipe.items, recipe.text);
    });
});
